#' Function to return the RA7 hydrologic indicator statistic for a given data frame
#' 
#' This function accepts a data frame that contains a column named "discharge" and 
#' calculates the median change in log of discharge for days with negative change for the entire record
#' 
#' @param qfiletempf data frame containing a "discharge" column containing daily flow values
#' @return ra7 numeric containing the median log of discharge change for days with negative change for the given data frame
#' @export
#' @examples
#' load_data<-paste(system.file(package="HITHATStats"),"/data/obs_data.csv",sep="")
#' qfiletempf<-read.csv(load_data)
#' ra7(qfiletempf)
ra7 <- function(qfiletempf) {
  sub_length <- nrow(qfiletempf)-1
  pos_flow_diff <- rep(0,sub_length)
  for (i in 1:sub_length) {
    if (qfiletempf$discharge[i+1] - qfiletempf$discharge[i] < 0) { 
      pos_flow_diff[i] <- log10(qfiletempf$discharge[i+1]) - log10(qfiletempf$discharge[i])
    }
  }
  sub_flow_diff <- subset(pos_flow_diff,pos_flow_diff<0)
  ra7 <- median(sub_flow_diff)
  return(ra7)
}