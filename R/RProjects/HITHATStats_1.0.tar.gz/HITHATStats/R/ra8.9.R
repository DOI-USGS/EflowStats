#' Function to return the RA8 and RA9 hydrologic indicator statistics for a given data frame
#' 
#' This function accepts a data frame that contains a column named "discharge" and 
#' calculates the variability and mean annual changes in flow from one day to the next for the entire record
#' 
#' @param qfiletempf data frame containing a "discharge" column containing daily flow values
#' @return ra8.9 list containing the variability and mean annual changes in flow from one day to the next for the given data frame
#' @export
#' @examples
#' load_data<-paste(system.file(package="HITHATStats"),"/data/obs_data.csv",sep="")
#' qfiletempf<-read.csv(load_data)
#' ra8.9(qfiletempf)
ra8.9 <- function(qfiletempf) {
  sub_length <- nrow(qfiletempf)-1
  flow_diff <- rep(0,sub_length)
  year_val <- rep(0,sub_length)
  for (i in 1:sub_length) {
    if (qfiletempf$discharge[i+1] - qfiletempf$discharge[i] < 0) { 
      flow_diff[i] <- -1
      year_val[i] <- qfiletempf$year_val[i+1]
    } else if (qfiletempf$discharge[i+1] - qfiletempf$discharge[i] >0) {
      flow_diff[i] <- 1 
      year_val[i] <- qfiletempf$year_val[i+1]
    } else { 
      flow_diff[i] <- 0 
    year_val[i] <- qfiletempf$year_val[i+1]
    }
  }
  year_flow_diff <- data.frame(year_val,flow_diff,stringsAsFactors=FALSE)
  yearly_diff <- diff(year_flow_diff$flow_diff, lag = 1, 
                     differences = 1)
  yearly_diff_yr <- data.frame(year_val[1:nrow(year_flow_diff)-1],yearly_diff,stringsAsFactors=FALSE)
  sub_flow_diff <- subset(yearly_diff_yr,yearly_diff_yr$yearly_diff==0)
  sub_flow_diff$yearly_diff <- sub_flow_diff$yearly_diff+1
  diff_by_year <- aggregate(sub_flow_diff$yearly_diff,list(sub_flow_diff$year_val),sum)
  ra8 <- mean(diff_by_year$x)
  sd_diff <- sd(diff_by_year$x)
  ra9 <- (sd_diff*100)/ra8
  ra8.9 <- list(ra8=ra8,ra9=ra9)
  return(ra8.9)
}