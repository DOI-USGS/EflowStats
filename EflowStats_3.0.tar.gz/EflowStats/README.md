EflowStats
===========

Returns HIT/HAT Hydrologic Indicator stats for a given set of data

To install this package use the following code:
install.packages("EflowStats",repos="http://usgs-r.github.com",type="source")
