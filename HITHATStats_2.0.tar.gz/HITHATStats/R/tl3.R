#' Function to return the TL3 hydrologic indicator statistic for a given data frame
#' 
#' This function accepts a data frame that contains a column named "discharge" and a threshold value obtained 
#' using the peakdata and getPeakThresh functions and calculates 
#' TL3; Seasonal predictability of low flow. Divide years up into 2-month periods (that is, Oct-Nov, Dec-Jan, and 
#' so forth). Count the number of low flow events (flow events with flows ??? 5 year flood threshold) in each period 
#' over the entire flow record. TL3 is the maximum number of low flow events in any one period divided by the total 
#' number of low flow events (dimensionless-spatial).
#' 
#' @param qfiletempf data frame containing a "discharge" column containing daily flow values
#' @param thresh value containing the 5-year recurrence value for the site
#' @return tl3 numeric containing TL3 for the given data frame
#' @export
#' @examples
#' load_data<-paste(system.file(package="HITHATStats"),"/data/obs_data.csv",sep="")
#' qfiletempf<-read.csv(load_data)
#' tl3(qfiletempf, 1161.38)
tl3 <- function(qfiletempf, thresh) {
  lfcrit <- thresh
  qfiletempf$season <- ifelse(as.numeric(qfiletempf$month)==10,10,ifelse(as.numeric(qfiletempf$month)==11,10,ifelse(as.numeric(qfiletempf$month)==12,12,ifelse(as.numeric(qfiletempf$month)==1,12,ifelse(as.numeric(qfiletempf$month)==2,2,ifelse(as.numeric(qfiletempf$month)==3,2,ifelse(as.numeric(qfiletempf$month)==4,4,ifelse(as.numeric(qfiletempf$month)==5,4,ifelse(as.numeric(qfiletempf$month)==6,6,ifelse(as.numeric(qfiletempf$month)==7,6,ifelse(as.numeric(qfiletempf$month)==8,8,ifelse(as.numeric(qfiletempf$month)==9,8,99))))))))))))
  nomonyears <- aggregate(qfiletempf$discharge, list(qfiletempf$wy_val,qfiletempf$season), 
                          FUN = median, na.rm=TRUE)
  colnames(nomonyears) <- c("Year","season", "momax")
  nomonyrs <- length(nomonyears$Year)
  nlf <- rep(0,6)
  tnlf <- 0
  for (i in 1:nomonyrs) {
    monyears <- nomonyears[i,]
    colnames(monyears) <- c("wy_val","season","momax")
    subsetyr <- merge(qfiletempf,monyears,by = c("wy_val","season"))
    flag <- 0
    for (j in 1:nrow(subsetyr)) {
      if (subsetyr$discharge[j]<=lfcrit) {
        flag <- flag+1
        tnlf <- ifelse(flag==1,tnlf+1,tnlf)
        season <- ifelse(subsetyr$season[j]==10,1,ifelse(subsetyr$season[j]==12,2,ifelse(subsetyr$season[j]==2,3,ifelse(subsetyr$season[j]==4,4,ifelse(subsetyr$season[j]==6,5,6)))))
        nlf[season] <- ifelse(flag==1,nlf[season]+1,nlf[season])
      } else {flag <- 0}
    }
  }
  tl3 <- max(nlf)/tnlf
  return(tl3)
}